//
//  SliderImage.swift
//  Metin2Hanesi
//
//  Created by NomoteteS on 15.04.2023.
//

import SwiftUI

struct SliderImage {
    var UIImage: UIImage
}
