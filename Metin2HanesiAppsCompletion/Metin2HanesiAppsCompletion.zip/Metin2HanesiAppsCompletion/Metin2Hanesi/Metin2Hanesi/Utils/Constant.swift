//
//  Constant.swift
//  Metin2Hanesi
//
//  Created by NomoteteS on 19.03.2023.
//

import Foundation
import Firebase
import FirebaseFirestore

let COLLECTION_Massage = Firestore.firestore().collection("messages")
