//
//  AddDataServerModel.swift
//  Metin2HanesiAdminPanel
//
//  Created by NomoteteS on 19.03.2023.
//

import Foundation

struct AddDataServerModel {
    let buttonTitle: String
    let viewOpenCode: ViewState?
}
