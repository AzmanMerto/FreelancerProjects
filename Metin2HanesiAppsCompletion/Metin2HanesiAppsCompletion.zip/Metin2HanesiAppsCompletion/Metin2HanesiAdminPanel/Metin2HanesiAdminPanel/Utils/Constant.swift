//
//  Constant.swift
//  Metin2HanesiAdminPanel
//
//  Created by NomoteteS on 19.03.2023.
//

import Firebase

let COLLECTION_thisWeekServer = Firestore.firestore().collection("thisWeekServer")
let COLLECTION_VSServer = Firestore.firestore().collection("VSServer")
let COLLECTION_55_120Server = Firestore.firestore().collection("55-120Server")
let COLLECTION_1_99Server = Firestore.firestore().collection("1-99Server")
let COLLECTION_1_120Server = Firestore.firestore().collection("1-120Server")
let COLLECTION_1_105Server = Firestore.firestore().collection("1-105Server")
